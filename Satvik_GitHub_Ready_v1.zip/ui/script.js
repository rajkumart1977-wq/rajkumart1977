
const data = {
  "ingredients": {},
  "masalas": {
    "masalas": [],
    "notes": "Base structure created. Full masala data will be merged during final consolidation."
  },
  "dishes": {
    "dishes": [],
    "notes": "Base dish structure created. Full dish data (ingredients, steps, masala mapping) will be merged during final consolidation."
  },
  "links_scaling": {
    "dish_to_masala": {},
    "dish_to_ingredients": {},
    "autoscale_rules": {},
    "serving_portion_defaults": {},
    "links": {
      "dish_to_masala": {},
      "dish_to_ingredients": {}
    },
    "scaling": {
      "autoscale_rules": {},
      "serving_portion_defaults": {}
    },
    "notes": "Base linking/scaling structure. All mappings and rules will be populated during final consolidation."
  },
  "status": "Final Consolidated Master Dataset"
};

window.onload = function() {
    const dishSelect = document.getElementById("dishSelect");
    Object.keys(data.dishes).forEach(d => {
        let opt = document.createElement("option");
        opt.value = d;
        opt.textContent = d;
        dishSelect.appendChild(opt);
    });
}

function loadDish() {
    const d = document.getElementById("dishSelect").value;
    const serv = parseInt(document.getElementById("servings").value);

    const dishData = data.dishes[d] || {};

    document.getElementById("ingredients").textContent =
        JSON.stringify(dishData.ingredients || {}, null, 2);

    document.getElementById("masalas").textContent =
        JSON.stringify(dishData.masalas || {}, null, 2);

    document.getElementById("links").textContent =
        JSON.stringify(data.links_scaling || {}, null, 2);
}
