
# 🌼 Satvik Recipe System — GitHub Version

This repository contains:

- Full master dataset  
- UI (HTML/JS)  
- Autoscaling engine  
- Documentation  
- API-ready structure

Hare Krishna.
